import "./App.css";
import { useEffect, useState } from "react";
import {SendMessage} from './message';
import {Tetst} from './tetst';


function App() {
  const [messageList, setMessage] = useState([]);
  const [answer, setAnswer] = useState("");

    useEffect (() => {    
      // Изменяем заголовок html-страницы   
      document.title = `Хорошо! Это похвально ;)`;  
      });
      
  return (
    <div className="App">
      <h1>
        <SendMessage setMessage={setMessage} />
        {messageList.map((e) => (
          <div>{e}</div>
        ))}
        <div>
          `Здорово, что вы так считаете!`
        </div>
        <Tetst defaultNumber={0}/>
      </h1>

      <header className="App-header">
        <div className="block">
        </div>
      </header>
    </div>
  );
}

export default App;

