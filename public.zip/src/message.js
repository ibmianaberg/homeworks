import { useEffect, useState } from "react";

export const SendMessage = ({ setMessage }) => {
  const [text, setText] = useState("");
  const [author, setAuthor] = useState("");
  

  return (
    <div className="count">
      <div className="message_css">
        <input
          className="message_input"
          placeholder="Напишите сообщение..."
          type="text"
          value={text}
          onChange={(e) => {
            setText(e.target.value);
          }}
        />
        <input
          className="message_input"
          placeholder="Ваше имя"
          type="text"
          value={author}
          onChange={(e) => {
            setAuthor(e.target.value);
          }}
        />
        <button
          className="button"
          onClick={() => {
            setMessage((p) => [...p, text, author])
            setAnswer((p)=> [...p, answer]);
          }}
        >
          Отправить в интернеты
        </button>
      
       
      </div>
    </div>
  );
};

